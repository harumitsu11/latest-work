<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <thead>
                        <th>イベント一覧</th>
                        <th>&nbsp;</th>
                    </thead>

                    <!-- テーブル本体 -->
                    <tbody>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <!-- 本タイトル -->
                                <td class="table-text">
                                    <div><?php echo e($book->item_name); ?></div>
                                    <div><?php echo e($book->item_number); ?>名</div>
                                    <div><?php echo e($book->item_amount); ?>円</div>
                                    <div><?php echo e($book->published); ?></div>
                                    <div><?php echo e($book->description); ?></div>
                                    <div><?php echo e($book->location); ?></div>
                                    
                                       <img src="./storage/upload/<?php echo e($book->image); ?>" width="400" height="250" alt="">

                                </td>
                            </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                                <div class="col-md-4 offset-md-4">
                                   <?php echo e($books->links()); ?>

                                 </div>
                              </div>
    
</body>
</html>