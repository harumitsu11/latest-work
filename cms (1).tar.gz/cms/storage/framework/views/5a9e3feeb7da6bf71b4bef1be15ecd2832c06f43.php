<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php echo e($eventData->item_name); ?>

    <?php echo e($eventData->item_number); ?>

    <?php echo e($eventData->item_amount); ?>

    <?php echo e($eventData->published); ?>

    <?php echo e($eventData->location); ?>

    <?php echo e($eventData->description); ?>

    <?php echo e($eventData->image); ?>

    <img src="../storage/upload/<?php echo e($eventData->image); ?>" width="400" height="250" alt="">　
    
    <div class="well well-sm">
            <button type="submit" class="btn btn-primary">キャンセル</button>
            <a class="btn btn-link pull-right" href="<?php echo e(url('/')); ?>">
               
            </a>
        </div>
        

</body>

</html>